const https = require('https');
const { SmartPaySDK } = require("@coinsmart/smartpay-sdk");

const smartpay = new SmartPaySDK('739f4b08-d310-4c33-b256-555915353df2','j0tTp_tpjjTLGTDOKgYpQDcP0yvG0aV.tqP3j856hsYZTBsHT549selKse1u.HAz', 'https://smartpay-api.coinsmart.com/v1/invoices');

async function myFunction() {
    const payload = {
        productSymbol: 'USD',
        amount: '20',
        email: 'coderzbar@gmail.com',
        details: {
            "Product A": {
                "quantity": 1,
                "price": 10.00
            }
        },
        sendEmail: true
    };
try {
    const invoice = await smartpay.createInvoice(payload);
    console.log(invoice);
} catch (error){
    console.error(error);
}
}

myFunction();